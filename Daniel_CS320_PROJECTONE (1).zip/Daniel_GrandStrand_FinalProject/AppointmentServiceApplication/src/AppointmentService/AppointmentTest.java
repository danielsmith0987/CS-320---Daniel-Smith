package AppointmentService;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;


public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appt = new Appointment("1234567890", futureDate, "Doctor visit");
        assertEquals("1234567890", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Doctor visit", appt.getDescription());
    }

    @Test
    public void testInvalidIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup");
        });
    }

    @Test
    public void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Checkup");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDesc = "This description is definitely more than fifty characters long!";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, longDesc);
        });
    }
}
