package com.taskservice;

public class Task {
    private final String taskId; // Made final to enforce immutability
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not exceed 10 characters.");
        }
        if (name == null) {
            throw new IllegalArgumentException("Name must not be null.");
        }
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Name must not be null.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null.");
        }
        this.description = description;
    }
}
