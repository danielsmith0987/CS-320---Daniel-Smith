package com.taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("T123", "Update docs", "Make sure README is up to date.");
        assertEquals("T123", task.getTaskId());
        assertEquals("Update docs", task.getName());
        assertEquals("Make sure README is up to date.", task.getDescription());
    }

    @Test
    void testInvalidTaskId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
        assertTrue(exception.getMessage().contains("Task ID must not exceed"));
    }

    @Test
    void testNullNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", null, "Valid description");
        });
    }

    @Test
    void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T002", "Valid name", null);
        });
    }

    @Test
    void testSetName() {
        Task task = new Task("T003", "Initial", "Initial description");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    void testSetDescription() {
        Task task = new Task("T004", "Initial", "Initial description");
        task.setDescription("Updated description");
        assertEquals("Updated description", task.getDescription());
    }
}
