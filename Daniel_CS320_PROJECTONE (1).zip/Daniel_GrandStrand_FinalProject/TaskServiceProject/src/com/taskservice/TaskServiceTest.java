package com.taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = service.addTask("Docs", "Update README");
        assertNotNull(task);
        assertEquals("Docs", task.getName());
        assertEquals("Update README", task.getDescription());
    }

    @Test
    public void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = service.addTask("Initial", "Initial Description");

        boolean result = service.updateTask(task.getTaskId(), "Updated", "Updated Description");
        assertTrue(result);

        Task updatedTask = service.getTask(task.getTaskId());
        assertEquals("Updated", updatedTask.getName());
        assertEquals("Updated Description", updatedTask.getDescription());
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = service.addTask("ToDelete", "Temporary");

        boolean result = service.deleteTask(task.getTaskId());
        assertTrue(result);

        Task deleted = service.getTask(task.getTaskId());
        assertNull(deleted);
    }

    @Test
    public void testGetTaskReturnsNullForMissingTask() {
        TaskService service = new TaskService();
        Task result = service.getTask("NonExistentID");
        assertNull(result);
    }
}

