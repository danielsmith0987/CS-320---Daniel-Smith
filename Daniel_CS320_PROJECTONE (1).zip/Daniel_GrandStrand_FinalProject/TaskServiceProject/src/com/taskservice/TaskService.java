package com.taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>();
    private int idCounter = 1;

    // Adds a task and returns it for easier testing
    public Task addTask(String name, String description) {
        String taskId = generateUniqueId();
        Task task = new Task(taskId, name, description);
        tasks.put(taskId, task);
        return task;
    }

    public boolean updateTask(String taskId, String newName, String newDescription) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setName(newName);
            task.setDescription(newDescription);
            return true;
        }
        return false;
    }

    public boolean deleteTask(String taskId) {
        return tasks.remove(taskId) != null;
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // Ensures task ID is exactly 10 characters long and readable
    private String generateUniqueId() {
        String base = "T" + String.format("%09d", idCounter++);
        return base.length() > 10 ? base.substring(0, 10) : base;
    }
}

