package com.contactservice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact c = new Contact("ID1", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("ID1", c.getContactId());
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ID2", "Jane", "Smith", "badPhone", "456 Elm St");
        });
    }

    @Test
    public void testUpdateName() {
        Contact c = new Contact("ID3", "Tom", "Hill", "1112223333", "789 Oak St");
        c.setFirstName("Tim");
        assertEquals("Tim", c.getFirstName());
    }
}
