package com.contactservice;

public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validate(contactId, 10, "Contact ID");
        validate(firstName, 10, "First Name");
        validate(lastName, 10, "Last Name");
        validatePhone(phone);
        validate(address, 30, "Address");

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    private void validate(String value, int maxLength, String fieldName) {
        if (value == null || value.length() > maxLength)
            throw new IllegalArgumentException(fieldName + " must be ≤ " + maxLength + " characters and not null.");
    }

    private void validatePhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}"))
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
    }

    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    public void setFirstName(String firstName) { validate(firstName, 10, "First Name"); this.firstName = firstName; }
    public void setLastName(String lastName) { validate(lastName, 10, "Last Name"); this.lastName = lastName; }
    public void setPhone(String phone) { validatePhone(phone); this.phone = phone; }
    public void setAddress(String address) { validate(address, 30, "Address"); this.address = address; }
}
