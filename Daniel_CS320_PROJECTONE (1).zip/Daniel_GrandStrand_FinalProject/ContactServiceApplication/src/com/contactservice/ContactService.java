package com.contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public boolean addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) return false;
        contacts.put(contact.getContactId(), contact);
        return true;
    }

    public boolean deleteContact(String contactId) {
        return contacts.remove(contactId) != null;
    }

    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact c = contacts.get(contactId);
        if (c == null) return false;

        try {
            if (firstName != null) c.setFirstName(firstName);
            if (lastName != null) c.setLastName(lastName);
            if (phone != null) c.setPhone(phone);
            if (address != null) c.setAddress(address);
        } catch (IllegalArgumentException e) {
            System.out.println("Update error: " + e.getMessage());
            return false;
        }

        return true;
    }

    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
