package com.contactservice;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact c = new Contact("ID10", "Amy", "Green", "2223334444", "135 Willow Dr");
        assertTrue(service.addContact(c));
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact c = new Contact("ID20", "Jack", "Black", "5556667777", "22 Vine Ln");
        service.addContact(c);
        assertTrue(service.deleteContact("ID20"));
    }

    @Test
    public void testUpdateContactInfo() {
        ContactService service = new ContactService();
        Contact c = new Contact("ID30", "Joe", "King", "8889990000", "94 Cedar St");
        service.addContact(c);
        assertTrue(service.updateContact("ID30", "Joel", null, null, "96 Cedar St"));
        assertEquals("Joel", service.getContact("ID30").getFirstName());
    }
}
